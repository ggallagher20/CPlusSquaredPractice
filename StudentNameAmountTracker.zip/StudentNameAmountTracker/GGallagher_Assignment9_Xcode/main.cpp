//
//  main.cpp
//  GGallagher_Assignment9_Xcode
//
//  Created by Gillian Gallagher on 10/28/20.
//

#include <iostream>

using namespace std;

string name;
int numberOfStudent = 0;

int main(){
    cout<<"==============================================="<<endl;
    cout<<"========Welcome to the Student Tracker========="<<endl;
    cout<<"==============================================="<<endl;
    
    cout<<"Enter student's names or STOP to quit: "<<endl;
    cin>>name;
    
    while (name!="STOP"){
        numberOfStudent++;
        cout<<"Enter other student's names or STOP to quit: "<<endl;
        cin>>name;
    }
    cout<<"Total registered students: "<<numberOfStudent<<endl;
}
