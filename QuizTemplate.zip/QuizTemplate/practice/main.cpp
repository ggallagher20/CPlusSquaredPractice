//
//  main.cpp
//  practice
//
//  Created by Gillian Gallagher on 9/30/20.
//

#include <iostream>

using namespace std;

float first, sec, result;
char option;
string name, a1, a2, a3, a4, a5;
int score;

int main(){
    cout<<"enter your name: ";
    cin>>name;
    
    cout<<"================================"<<endl;
    cout<<"==============Quiz=============="<<endl;
    cout<<"=======Fill in the blanks======="<<endl;
    cout<<"================================"<<endl;
    
    cout<<"#[ (1) ] < iostream"<<endl;
    
    cout<<"using [ (2) ] std;"<<endl;
    
    cout<<"[ (3) ] main (){ "<<endl;
    cout<<"     [ (4) ] name;"<<endl;
    cout<<"     cout<<Enter your name: <<endl;"<<endl;
    cout<<"     cout<<Hi, <<name<<endl;"<<endl;
    cout<<"}"<<endl;
    
    cout<<"================================"<<endl;
    
    cout<<"Answer (1): ";
    cin>>a1;
    cout<<"Answer (2): ";
    cin>>a2;
    cout<<"Answer (3): ";
    cin>>a3;
    cout<<"Answer (4): ";
    cin>>a4;
    cout<<"Answer (5): ";
    cin>>a5;
    
    if (a1 == "#include"){
        score++;
    }
    
    if(a2 == "namespace"){
        score++;
    }
    
    if(a3 == "int"){
        score++;
    }
    
    if(a4=="string"){
        score++;
    }
    
    if(a5=="cin"){
        score++;
    }
    
    cout<<name<<"'s Score: "<<score<<"/5"<<endl;
}
