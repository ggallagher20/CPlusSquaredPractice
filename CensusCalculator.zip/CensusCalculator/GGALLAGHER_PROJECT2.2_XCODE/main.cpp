//
//  main.cpp
//  GGALLAGHER_PROJECT2.2_XCODE
//
//  Created by Gillian Gallagher on 10/23/20.
//

#include <iostream>

using namespace std;

int members = 0;
float name;
char employ;

int main(){
    
    cout<<"======= Florida Census Program ======="<<endl;
    cout<<"How many family members do you have?: ";
    cin>>members;
    cout<<"======================================"<<endl;
    
    for(members = 0; members < 10; members++){
        cout<<"Family member 1"<<endl;
        cout<<"Name                      : ";
        cin>>name;
        cout<<"(E)mployed / (U)nemployed : ";
        cin>>employ;
    }
}
