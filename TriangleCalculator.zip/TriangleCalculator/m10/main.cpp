//
//  main.cpp
//  m10
//
//  Created by Gillian Gallagher on 11/6/20.
//

#include <iostream>

using namespace std;

// these are the int for the 3 user inputs
int first=0, sec=0, third=0;

int main(){
    //welcome message
    cout<<"==== Welcome to the Triangle Police! ==="<<endl;
    
    //user input
    cout<<"Enter the three angles of the triangle: "<<endl;
    cout<<"-1st: ";
    cin>>first;
    cout<<"-2nd: ";
    cin>>sec;
    cout<<"-3rd: ";
    cin>>third;
    cout<<"========================================"<<endl;
    
    //the result~!
    cout<<"Let's see if that's actually a triangle!"<<endl;
    int total = first + sec + third;
    if(total>180 || total<180){
        cout<<"These numbers don't form a triangle."<<endl;
    }else if(total == 180){
        cout<<"These numbers create a triangle! Wow!"<<endl;
    }
}
