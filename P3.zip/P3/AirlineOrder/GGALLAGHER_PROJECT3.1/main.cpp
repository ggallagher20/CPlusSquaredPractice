//
//  main.cpp
//  GGALLAGHER_PROJECT3.1
//
//  Created by Gillian Gallagher on 12/4/20.
//

#include <iostream>

using namespace std;

string fname, lname, email;
char choice, decision, seatchoice;
int total=0, tax=0, finalcharge=0;

void welcome(){
    cout<<"Please enter your FIRST name: ";
    cin>>fname;
    cout<<"Please enter your LAST name: ";
    cin>>lname;
    cout<<"Please enter your EMAIL: ";
    cin>>email;
}

void menu(){
    cout<<"Please select your Winter Sale Package"<<endl;
    cout<<"(Promo is limited to one [1] ticket per person)"<<endl;
    cout<<"(A) GNV-JFK-GNV ($25/seat)"<<endl;
    cout<<"(B) MCO-LAX-MCO ($55/seat)"<<endl;
    cout<<"(C) GNV-LAS-GNV ($50/seat)"<<endl;
    cout<<"Package Selection: ";
    cin>>choice;
    
    switch (choice){
        case 'A':
        case 'a':
            total+=25;
            break;
        case 'B':
        case 'b':
            total+=55;
            break;
        case 'C':
        case 'c':
            total+=50;
            break;
        default:
            cout<<"Incorrect choice selection. Please restart the program!"<<endl;
    }
    cout<<"Great Choice, "<<fname<<" "<<lname<<"."<<endl;
}

void checkout(){
    cout<<"Your total             : $"<<total<<endl;
    tax = (total * 0.10);
    cout<<"Airport Charge + Taxes : $"<<tax<<endl;
    finalcharge = total + tax;
    cout<<"Amount to be paid      : $"<<finalcharge<<endl;
}

void seat(){
    cout<<"Press 'Y' to select your seat, or 'N' to proceed with the payment."<<endl;
    cin>>decision;
    
    if(decision == 'Y' || decision == 'y'){
        
        cout<<"      o o  o  o  o  o o       "<<endl;
        cout<<"    o                   o     "<<endl;
        cout<<"------------------------------"<<endl;
        cout<<"   o [A] [x]      [x] [x] o   "<<endl;
        cout<<"  o  [x] [x]      [B] [C]  o   +$45 "<<endl;
        cout<<"------------------------------"<<endl;
        cout<<"o   [x][x][x]    [x][x][x]  o "<<endl;
        cout<<"o   [x][x][x]    [D][E][x]  o "<<endl;
        cout<<"o   [x][F][x]    [x][x][x]  o  +$25 "<<endl;
        cout<<"o   [x][x][G]    [x][H][x]  o "<<endl;
        cout<<"o   [x][x][x]    [x][x][x]  o "<<endl;
        cout<<"------------------------------"<<endl;
        
        cout<<"Seat Selection: ";
        cin>>seatchoice;
        
        switch(seatchoice){
            case 'A':
            case 'a':
            case 'B':
            case 'b':
            case 'C':
            case 'c':
                total = total + 45;
                break;
            case 'D':
            case 'd':
            case 'E':
            case 'e':
            case 'F':
            case 'f':
            case 'G':
            case 'g':
            case 'H':
            case 'h':
                total = total + 25;
                break;
        }
        
        checkout();
        
    }else if(decision == 'N' || decision =='n'){
        checkout();
    }
}

int main(){
    cout<<"Welcome to CheapCheapHurray Online Reservations!"<<endl;
    welcome();
    cout<<endl;
    menu();
    cout<<endl;
    seat();
    cout<<endl;
    cout<<"Your booking confirmation has been sent to "<<email<<endl;
    cout<<"Thank you for your reservation, "<<fname<<" "<<lname<<". Enjoy your trip!!!"<<endl;
    cout<<endl;
}
