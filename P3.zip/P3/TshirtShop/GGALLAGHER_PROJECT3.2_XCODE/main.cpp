//
//  main.cpp
//  GGALLAGHER_PROJECT3.2_XCODE
//
//  Created by Gillian Gallagher on 12/4/20.
//

#include <iostream>

using namespace std;

int main(){
    bool quit = false;
    char purchaseOpt;
    int purchaseOne, gcAmount;
    cout<<endl;
    
    cout<<"Gator GAME DAY SALE: T-shirts for $10 and Hats for $5"<<endl;
    cout<<"Swipe your GatorONE Card to check your balance: $";
    cin>>gcAmount;
    if(gcAmount <= 5 ){
        cout<<"Not enough funds are in your account. Sorry!"<<endl;
        quit=true;
    }else{
        while(!quit){
            cout<<"Want to purchase (Y/N)?: ";
            cin>>purchaseOpt;
            if(purchaseOpt == 'Y' || purchaseOpt == 'y'){
                cout<<"(1) T-Shirt $10        (2) Hat $5"<<endl;
                cout<<"Selection: ";
                cin>>purchaseOne;
                if(purchaseOne==1){
                    gcAmount-=10;
                }else if(purchaseOne==2){
                    gcAmount-=5;
                }
                cout<<"GatorONE Card balance: $"<<gcAmount<<endl;
                    if(gcAmount <= 5 ){
                        cout<<"Thanks for shopping!"<<endl;
                        quit=true;
                    }else{
                        
                    }
            }else if(purchaseOpt == 'N' || purchaseOpt == 'n'){
                cout<<"Thanks for shopping"<<endl;
                quit = true;
            }
            if(gcAmount<=0){
                cout<<"Thanks for shopping"<<endl;
                quit=true;
            }
        }
    }
    
}
