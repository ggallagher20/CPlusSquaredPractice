//
//  main.cpp
//  P2
//
//  Created by Gillian Gallagher on 11/6/20.
//

#include <iostream>

using namespace std;

int wallet=0;
int choice=0;
char decision;

int main(){
    cout<<"====================================="<<endl;
    cout<<"Welcome to the Gators Vending Machine"<<endl;
    cout<<"====================================="<<endl;
    cout<<"Please insert your bills!"<<endl;
    cout<<"(1)$1, (2)$5, (3)$10, (4)$20 : "<<endl;
    cin>>choice;
    
    switch(choice){
        case 1:
            wallet +=1;
            break;
        case 2:
            wallet +=5;
            break;
        case 3:
            wallet +=10;
            break;
        case 4:
            wallet +=20;
            break;
    }
    
    cout<<"You've inserted: $"<<wallet<<endl;
    cout<<"Funds available: $"<<wallet<<endl;
    cout<<"Add more bills? ";
    cin>>decision;
    
    while(decision!='X' || decision !='x'){
        if(decision == 'Y' || decision == 'y'){
            cout<<"Please insert your bills!"<<endl;
            cout<<"(1)$1, (2)$5, (3)$10, (4)$20 : "<<endl;
            cin>>choice;
            
            switch(choice){
                case 1:
                    wallet +=1;
                    break;
                case 2:
                    wallet +=5;
                    break;
                case 3:
                    wallet +=10;
                    break;
                case 4:
                    wallet +=20;
                    break;
                default:
                    cout<<"Invalid selection.";
                    break;
            }
            
            cout<<"You've inserted: $"<<wallet<<endl;
            cout<<"Funds available: $"<<wallet<<endl;
            cout<<"Add more bills? ";
            cin>>decision;
        }
    }
    
}
