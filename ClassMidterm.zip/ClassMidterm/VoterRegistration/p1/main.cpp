//
//  main.cpp
//  p1
//
//  Created by Gillian Gallagher on 11/6/20.
//

#include <iostream>

using namespace std;

char answer;
int young=0,mid=0,old=0,age=0,no=0;

int main(){
    cout<<"Have you voted yet? (Y)es, (N)o, or (X) to EXIT ";
    cin>>answer;
    
    while(answer!='X'){
        if(answer=='Y'){
            cout<<"Age: ";
            cin>>age;
            
            if(age>=18 || age<=35){
                young++;
            }else if(age>=36 || age <=55){
                mid++;
            }else if(age>55){
                old++;
            }
        }else if(answer=='N'){
            no++;
        }
        cout<<"Have you voted yet? (Y)es, (N)o, or (X) to EXIT ";
        cin>>answer;
    }
    
    cout<<"Stop counting..."<<endl;
    int total = young + mid + old + no;
    cout<<"Survery Participants    : "<<total<<endl;
    
    int voted = young + mid + old;
    int perc1 = (voted / total)*100;
    cout<<"Voted                   : "<<voted<<"("<<perc1<<"%)"<<endl;
    cout<<"18 - 35 years old       : "<<young<<endl;
    cout<<"36 - 55 years old       : "<<mid<<endl;
    cout<<"> 55 years old          : "<<old<<endl;
    
    int perc2 = (no / total)*100;
    cout<<"Didn't vote             : "<<no<<"("<<perc2<<"%)"<<endl;
}
