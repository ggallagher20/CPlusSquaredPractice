//
//  main.cpp
//  CircleRadiusCalc
//
//  Created by Gillian Gallagher on 12/15/20.
//

#include <iostream>

using namespace std;

int main(){
    
    float radius;
    cout<<"Enter the radius of a circle: ";
    cin>>radius;
    
    float area = 3.14 * (radius * radius);
    cout<<"The area A of a circle with a radius of "<<radius<<" =: "<<area<<endl;
    float circ = 2 * radius * 3.14;
    cout<<"The circumference C of a circle with a radius of "<<radius<<" =: "<<circ<<endl;
}
