//
//  main.cpp
//  SwitchLoop
//
//  Created by Gillian Gallagher on 12/15/20.
//

#include <iostream>

using namespace std;

bool quit = false;
char choice, decision;

int main (){

    while(!quit){
        cout<<"Do you want to play a game? (Y/N): ";
        cin>>choice;
        
        switch(choice){
            case 'Y':
            case 'y':
                
                
                cout<<"Playing the game..."<<endl;
                cout<<"Do you want to play a game, AGAIN? (Y/N): ";
                cin>>decision;
                
                    switch(decision){
                        case 'Y':
                        case 'y':
                            cout<<"Playing the game, AGAIN"<<endl;
                            break;
                        case 'N':
                        case 'n':
                            quit = true;
                            break;
                    }
                
                break;
                
            case 'N':
            case 'n':
                quit = true;
                break;
        }
    }
    cout<<"Exit the game"<<endl;
}
