//
//  main.cpp
//  j
//
//  Created by Gillian Gallagher on 10/21/20.
//

#include <iostream>

using namespace std;

bool quit = false;
char choice;
float price = 0;
float total = 0;

int main (){
    cout<<"==========================="<<endl;
    cout<<"Welcome to the Hype Sneaker"<<endl;
    cout<<"==========================="<<endl;
    
    while(!quit){
        cout<<"Add shoes (Y/N)? : ";
        cin>>choice;
        
        switch(choice){
            case 'Y':
            case 'y':
                cout<<"Price: $ ";
                cin>>price;
                total += price;
                cout<<"Total: $ "<<total<<endl;
                break;
            
            case 'N':
            case 'n':
                quit = true;
                break;
        }
        
    
        
    }
    cout<<"==========================="<<endl;
    cout<<"Sales amount        : "<<total<<endl;
    float tax = total * .02;
    cout<<"Sales tax (2%)      : "<<tax<<endl;
    float ftotal = total + tax;
    cout<<"Your grand total is : "<<ftotal<<endl;
    cout<<"Thanks for shopping with us"<<endl;
    cout<<"==========================="<<endl;
    
    
}
