//
//  main.cpp
//  CubeVolumeCalculator
//
//  Created by Gillian Gallagher on 12/15/20.
//

#include <iostream>

using namespace std;

int main(){
    
    float side;
    
    cout<<"Enter the side(s) of the cube: ";
    cin>>side;
    
    float volume = side * side * side;
    cout<<"The volume of the cube is: "<<volume<<endl;
    
}
