//
//  main.cpp
//  idk
//
//  Created by Gillian Gallagher on 10/7/20.
//

#include <iostream>

using namespace std;

string name, player;
int map, item;
char gameChoice;

int main(){
    
    cout<<"Welcome to CounterStroke 2.0"<<endl;
    cout<<"=======GNV Division========="<<endl;
    
    cout<<"(N)ew Game, (Q)uit: ";
    cin>>gameChoice;
    
    cout<<"Host Name: ";
    cin>>name;
    
    cout<<"Map Selections: (1)De_GriffinHill (2)De_OukMall (3)CS_BobDidley (4)CS_LakeAlice"<<endl;
    cin>>map;
    
    cout<<"Max Player: ";
    cin>>player;
    
    cout<<"(1) DessertWiggle, (2) DualBarista, (3)BullPop, (4)MagnumSnider"<<endl;
    cin>>item;
    
    switch (gameChoice){
        case 'N' :
            switch(map){
                case 1:
                    cout<<"Host          : "<<name<<endl;
                    cout<<"Map           : De_GriffinHall"<<endl;
                    cout<<"Max Player    :"<<player<<endl;
                    cout<<"Selected Item :"<<item<<endl;
                    cout<<"Launching the map !!!"<<endl;
                    break;
                    
                case 2:
                    cout<<"Host          : "<<name<<endl;
                    cout<<"Map           : De_OukMall"<<endl;
                    cout<<"Max Player    :"<<player<<endl;
                    cout<<"Selected Item :"<<item<<endl;
                    cout<<"Launching the map !!!"<<endl;
                    break;
                    
                case 3:
                    cout<<"Host          : "<<name<<endl;
                    cout<<"Map           : CS_BobDidley"<<endl;
                    cout<<"Max Player    :"<<player<<endl;
                    cout<<"Selected Item :"<<item<<endl;
                    cout<<"Launching the map !!!"<<endl;
                    break;
                    
                case 4:
                    cout<<"Host          : "<<name<<endl;
                    cout<<"Map           : CS_LakeAlice"<<endl;
                    cout<<"Max Player    :"<<player<<endl;
                    cout<<"Selected Item :"<<item<<endl;
                    cout<<"Launching the map !!!"<<endl;
                    break;
            }
            break;
        case 'Q':
            cout<<"Ok! Have a nice day.";
            break;
    }
    
}
