//
//  main.cpp
//  GGALLAGHER_ASSIGNMENT14_XCODE
//
//  Created by Gillian Gallagher on 12/4/20.
//

#include <iostream>

using namespace std;

class StudentClass{
    public:
        void studentInformation(string name, string profession, int age, int grade){
            cout<<endl;
            cout<<"Student Name: "<<endl;
            cout<<" - Major    : "<<endl;
            cout<<" - Age      : "<<endl;
            cout<<" - GPA      : "<<endl;
            cout<<endl;
        }
};

int main(){
    StudentClass markusObj;
    markusObj.studentInformation("Markus Santoso", "Digital Worlds Institute", 20, 4.0);
    
    StudentClass stephen;
    stephen.studentInformation("Stephen Forest", "Journalism", 19, 3.9);
}
